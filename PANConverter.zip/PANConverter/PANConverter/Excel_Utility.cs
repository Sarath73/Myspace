﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Excel = Microsoft.Office.Interop.Excel;
using System.Data;

namespace PANConverter
{
    public static class Excel_Utility
    {
        private static Excel.Application app;
        private static Excel.Workbook book;
        private static Excel.Worksheet sheet;
        
        /// This method would read the data from excel and return the Data table
        /// And this returns the data as Datatable
        public static DataTable ReadData(String fileName, String sheetName)
        {
            List<String> cName = new List<string>();
            //Create a data table with Sheet Name
            DataTable myTable = new DataTable(sheetName);
            try
            {
                app = new Excel.Application();
                book = app.Workbooks.Open(fileName);
                app.DisplayAlerts = false;
                app.Visible = false;
                sheet = (Microsoft.Office.Interop.Excel.Worksheet)book.Sheets[sheetName];

                //Get the used range of the cells in the sheet
                Excel.Range usedRangeInSheet = sheet.UsedRange;

                //Add columns to the list
                for (int i = 0; i < usedRangeInSheet.Columns.Count; i++)
                {
                    String temp = (usedRangeInSheet.Cells[1, i+1] as Excel.Range).Value2.ToString();
                    cName.Add(temp);
                }
                
                //Add columns to the Data Table
                for(int i = 0; i < cName.Count; i++)
                {
                    myTable.Columns.Add(cName[i].ToString());
                }

                for (int i = 1; i < usedRangeInSheet.Rows.Count; i++)
                {
                    //Initially Add blank rows to the table
                    String column1Data = "";
                    myTable.Rows.Add(column1Data);
                    //Now Add Rows to a specific column.
                    for(int x = 0; x < cName.Count; x++)
                    {
                        myTable.Rows[i - 1][cName[x].ToString()] = (usedRangeInSheet.Cells[i + 1, x+1] as Excel.Range).Value2.ToString();
                    }
                }
            }

            catch (Exception e)
            {
                throw e;
            }

            finally
            {
                book.Close();
                app.Quit();
            }

            return myTable;
        }

        /// This method would write the data to excel from the Data table returned by the ReadData method
        /// This method returns a boolean value if it successfully write the data

        public static bool WriteDataToExcel(String filename, String sheetName, DataTable myTable)
        {
            bool isDataWritten = false;
            try
            {
                app = new Excel.Application();
                book = app.Workbooks.Open(filename);
                app.DisplayAlerts = false;
                app.Visible = false;

                foreach(Excel.Worksheet sh in book.Sheets)
                {
                    if(sh.Name == sheetName)
                    {
                        sh.Delete();
                        break;
                    }
                }
                sheet = (Microsoft.Office.Interop.Excel.Worksheet)book.Sheets.Add();
                sheet.Name = sheetName;

                //Initially write column names to the excel sheet
                for (int i = 1; i <= myTable.Columns.Count; i++)
                {
                    sheet.Cells[1, i] = myTable.Columns[i - 1].ColumnName;
                }

                for (int j = 0; j < myTable.Rows.Count; j++)
                {
                    for (int k = 0; k < myTable.Columns.Count; k++)
                    {
                        sheet.Cells[j + 2, k + 1] = myTable.Rows[j].ItemArray[k].ToString();
                    }
                }
                isDataWritten = true;
            }

            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                isDataWritten = false;
            }

            finally
            {
                book.Save();
                book.Close();
                app.Quit();
            }
            return isDataWritten;
        }
    }
}
