﻿namespace PANConverter
{
    partial class PAN_Converter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Input_File_Name = new System.Windows.Forms.Label();
            this.textBox_InputFileName = new System.Windows.Forms.TextBox();
            this.button_Input_OpenFile = new System.Windows.Forms.Button();
            this.Output_File_Name = new System.Windows.Forms.Label();
            this.button_Encrypt = new System.Windows.Forms.Button();
            this.button_Decrypt = new System.Windows.Forms.Button();
            this.button_Ouput_OpenFile = new System.Windows.Forms.Button();
            this.textBox_OutPutFileName = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Input_File_Name
            // 
            this.Input_File_Name.AutoSize = true;
            this.Input_File_Name.Location = new System.Drawing.Point(40, 61);
            this.Input_File_Name.Name = "Input_File_Name";
            this.Input_File_Name.Size = new System.Drawing.Size(87, 13);
            this.Input_File_Name.TabIndex = 0;
            this.Input_File_Name.Text = "Input_File_Name";
            // 
            // textBox_InputFileName
            // 
            this.textBox_InputFileName.Location = new System.Drawing.Point(141, 58);
            this.textBox_InputFileName.Name = "textBox_InputFileName";
            this.textBox_InputFileName.ReadOnly = true;
            this.textBox_InputFileName.Size = new System.Drawing.Size(365, 20);
            this.textBox_InputFileName.TabIndex = 1;
            this.textBox_InputFileName.TextChanged += new System.EventHandler(this.textBox_InputFileName_TextChanged);
            // 
            // button_Input_OpenFile
            // 
            this.button_Input_OpenFile.Location = new System.Drawing.Point(548, 56);
            this.button_Input_OpenFile.Name = "button_Input_OpenFile";
            this.button_Input_OpenFile.Size = new System.Drawing.Size(124, 23);
            this.button_Input_OpenFile.TabIndex = 2;
            this.button_Input_OpenFile.Text = "Browse..";
            this.button_Input_OpenFile.UseVisualStyleBackColor = true;
            this.button_Input_OpenFile.Click += new System.EventHandler(this.button_Input_OpenFile_Click);
            // 
            // Output_File_Name
            // 
            this.Output_File_Name.AutoSize = true;
            this.Output_File_Name.Location = new System.Drawing.Point(40, 115);
            this.Output_File_Name.Name = "Output_File_Name";
            this.Output_File_Name.Size = new System.Drawing.Size(95, 13);
            this.Output_File_Name.TabIndex = 3;
            this.Output_File_Name.Text = "Output_File_Name";
            this.Output_File_Name.Click += new System.EventHandler(this.Output_File_Name_Click);
            // 
            // button_Encrypt
            // 
            this.button_Encrypt.Location = new System.Drawing.Point(141, 151);
            this.button_Encrypt.Name = "button_Encrypt";
            this.button_Encrypt.Size = new System.Drawing.Size(75, 23);
            this.button_Encrypt.TabIndex = 5;
            this.button_Encrypt.Text = "Encrypt";
            this.button_Encrypt.UseVisualStyleBackColor = true;
            this.button_Encrypt.Click += new System.EventHandler(this.button_Encrypt_Click);
            // 
            // button_Decrypt
            // 
            this.button_Decrypt.Location = new System.Drawing.Point(246, 151);
            this.button_Decrypt.Name = "button_Decrypt";
            this.button_Decrypt.Size = new System.Drawing.Size(75, 23);
            this.button_Decrypt.TabIndex = 6;
            this.button_Decrypt.Text = "Decrypt";
            this.button_Decrypt.UseVisualStyleBackColor = true;
            this.button_Decrypt.Click += new System.EventHandler(this.button_Decrypt_Click);
            // 
            // button_Ouput_OpenFile
            // 
            this.button_Ouput_OpenFile.Location = new System.Drawing.Point(548, 112);
            this.button_Ouput_OpenFile.Name = "button_Ouput_OpenFile";
            this.button_Ouput_OpenFile.Size = new System.Drawing.Size(124, 23);
            this.button_Ouput_OpenFile.TabIndex = 8;
            this.button_Ouput_OpenFile.Text = "Browse..";
            this.button_Ouput_OpenFile.UseVisualStyleBackColor = true;
            this.button_Ouput_OpenFile.Click += new System.EventHandler(this.button_Ouput_OpenFile_Click);
            // 
            // textBox_OutPutFileName
            // 
            this.textBox_OutPutFileName.Location = new System.Drawing.Point(141, 112);
            this.textBox_OutPutFileName.Name = "textBox_OutPutFileName";
            this.textBox_OutPutFileName.ReadOnly = true;
            this.textBox_OutPutFileName.Size = new System.Drawing.Size(365, 20);
            this.textBox_OutPutFileName.TabIndex = 9;
            this.textBox_OutPutFileName.TextChanged += new System.EventHandler(this.textBox_OutPutFileName_TextChanged);
            // 
            // PAN_Converter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(749, 300);
            this.Controls.Add(this.textBox_OutPutFileName);
            this.Controls.Add(this.button_Ouput_OpenFile);
            this.Controls.Add(this.button_Decrypt);
            this.Controls.Add(this.button_Encrypt);
            this.Controls.Add(this.Output_File_Name);
            this.Controls.Add(this.button_Input_OpenFile);
            this.Controls.Add(this.textBox_InputFileName);
            this.Controls.Add(this.Input_File_Name);
            this.Name = "PAN_Converter";
            this.Text = "PAN Converter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Input_File_Name;
        private System.Windows.Forms.TextBox textBox_InputFileName;
        private System.Windows.Forms.Button button_Input_OpenFile;
        private System.Windows.Forms.Label Output_File_Name;
        private System.Windows.Forms.Button button_Encrypt;
        private System.Windows.Forms.Button button_Decrypt;
        private System.Windows.Forms.Button button_Ouput_OpenFile;
        private System.Windows.Forms.TextBox textBox_OutPutFileName;
    }
}

