﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace PANConverter
{
    public partial class PAN_Converter : Form
    {
        public PAN_Converter()
        {
            InitializeComponent();
        }

        private void Output_File_Name_Click(object sender, EventArgs e)
        {
            
        }

        private void button_Decrypt_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Please wait while Decryption is in Progress", "Decryption is in Progress", MessageBoxButtons.OK);
            String sheetName = ConfigurationManager.AppSettings["SheetName"].ToString();
            DataTable myTable = Excel_Utility.ReadData(textBox_InputFileName.Text, sheetName);

            //Add a column to push the entrypted data
            myTable.Columns.Add("Decrypted PAN");
            
            //Do the encryption and write it to Data Table
            for (int rows = 0; rows < myTable.Rows.Count; rows++)
            {
                for (int cols = 0; cols < myTable.Columns.Count; cols++)
                {
                    String toDecrypt = myTable.Rows[rows][myTable.Columns[1].ColumnName].ToString();
                    String decryptedCardNumber = EncryptAndDecrypt.Decrypt(toDecrypt, true);
                    myTable.Rows[rows]["Decrypted PAN"] = decryptedCardNumber;
                }
            }
            MessageBox.Show("Successfullly Decrypted the CARD NUMBERS", "Encryption Completed", MessageBoxButtons.OK);

            //Now write the encryted data to excel from data table
            Excel_Utility.WriteDataToExcel(textBox_OutPutFileName.Text, sheetName, myTable);
            MessageBox.Show("Successfullly written the Decrypted CARD NUMBERS to Excel File", "Written Data to Excel", MessageBoxButtons.OK);

        }

        private void textBox_InputFileName_TextChanged(object sender, EventArgs e)
        {
            //No code needed
        }

        private void button_Encrypt_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Please wait while encryption is in Progress", "Encryption is in Progress", MessageBoxButtons.OK);
            String sheetName = ConfigurationManager.AppSettings["SheetName"].ToString();
            
            DataTable myTable = Excel_Utility.ReadData(textBox_InputFileName.Text, sheetName);

            //Add a column to push the entrypted data
            myTable.Columns.Add("SerialNbr");
            
            //Do the encryption and write it to Data Table
            for (int rows = 0; rows < myTable.Rows.Count; rows++)
            {
                for (int cols = 0; cols < myTable.Columns.Count; cols++)
                {
                    String toEncrypt = myTable.Rows[rows][myTable.Columns[0].ColumnName].ToString();
                    String encryptedCardNumber = EncryptAndDecrypt.Encrypt(toEncrypt, true);
                    myTable.Rows[rows]["SerialNbr"] = encryptedCardNumber;
                }
            }
            MessageBox.Show("Successfullly Encrypted the CARD NUMBERS","Encryption Completed",MessageBoxButtons.OK);

            //Now write the encryted data to excel from data table
            Excel_Utility.WriteDataToExcel(textBox_OutPutFileName.Text, sheetName, myTable);
            MessageBox.Show("Successfullly written the Encrypted CARD NUMBERS to Excel File","Written Data to Excel",MessageBoxButtons.OK);
        }

        private void button_Ouput_OpenFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.InitialDirectory = "c:\\";
            openFileDialog1.Filter = "Excel 2003-2007 (*.xls)|Excel Files*.xlsx|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    textBox_OutPutFileName.Text = openFileDialog1.FileName;
                }

                catch (Exception ex)
                {
                    MessageBox.Show("Error : Could not read the file from disk. Original Error :" + ex.ToString());
                }
            }
        }

        private void button_Input_OpenFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            openFileDialog1.InitialDirectory = "c:\\";
            openFileDialog1.Filter = "Excel 2003-2007 (*.xls)|Excel Files*.xlsx|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;

            if(openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    textBox_InputFileName.Text = openFileDialog1.FileName;
                }

                catch(Exception ex)
                {
                    MessageBox.Show("Error : Could not read the file from disk. Original Error :" + ex.ToString());
                }
            }
        }
        
        private void textBox_OutPutFileName_TextChanged(object sender, EventArgs e)
        {
            //No code needed
        }
    }
}